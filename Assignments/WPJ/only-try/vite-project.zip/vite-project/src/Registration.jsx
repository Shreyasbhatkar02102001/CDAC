// import 'bootstrap/dist/css/bootstrap.min.css';
// import { useState } from 'react'
// import './App.css'
// import BasicExample from './Components/Navbar'
// import CustomCarousel from './Components/CarouselCom'
// import ResponsiveExample from './Components/FormRegister';
// import Lfooter from './Components/FooterCom';

// export function Login() {
//     return (
//         <div>
//           <div>
//             <BasicExample />
//           </div>
//           <div>
//             <CustomCarousel />
//           </div>
//           <div>
//             <ResponsiveExample />
//           </div>
//           <div>
//             <Lfooter />
//           </div>
//         </div>
//       )
// }
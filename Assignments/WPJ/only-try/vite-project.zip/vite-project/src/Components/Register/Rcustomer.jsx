import React from 'react'
import React from 'react'
import BasicExample from './Components/Navbar'
import CarouselCustomerRegis from './CarouselCustomerRegis'
import ResponsiveExample from './FormRegister';
import Lfooter from './Components/FooterCom';

function Rcustomer() {   // Resgister
    const [count, setCount] = useState(0)
  
    return (
      <div>
        <div>
          <BasicExample />
        </div>
        <div>
          <CarouselCustomerRegis />
        </div>
        <div>
          <ResponsiveExample /> 
        </div>
        <div>
          <Lfooter />
        </div>
      </div>
    )
  }

  export default Rcustomer
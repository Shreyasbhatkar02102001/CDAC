import React from 'react'
import React from 'react'
import BasicExample from './Components/Navbar'
import CarouselAdminRegis from './CarouselAdminRegis'
import ResponsiveExample from './FormRegister';
import Lfooter from './Components/FooterCom';

function Radmin() {   // Resgister
    const [count, setCount] = useState(0)
  
    return (
      <div>
        <div>
          <BasicExample />
        </div>
        <div>
          <CarouselAdminRegis />
        </div>
        <div>
          <ResponsiveExample /> 
        </div>
        <div>
          <Lfooter />
        </div>
      </div>
    )
  }

  export default Radmin
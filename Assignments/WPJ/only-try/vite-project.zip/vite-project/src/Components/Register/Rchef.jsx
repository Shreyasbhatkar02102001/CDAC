import React from 'react'
import React from 'react'
import BasicExample from './Components/Navbar'
import CarouselChefRegis from './CarouselChefRegis'
import ResponsiveExample from './FormRegister';
import Lfooter from './Components/FooterCom';

function Rchef() {   // Resgister
    const [count, setCount] = useState(0)
  
    return (
      <div>
        <div>
          <BasicExample />
        </div>
        <div>
          <CarouselChefRegis />
        </div>
        <div>
          <ResponsiveExample /> 
        </div>
        <div>
          <Lfooter />
        </div>
      </div>
    )
  }

  export default Rchef
import React from 'react'
import BasicExample from './Components/Navbar'
import CarouselCustomerLogin from './CarouselCustomerLogin';
import SignIn from './Components/FormLogin';
import Lfooter from './Components/FooterCom';

function Scustomer() {
  return (
    <div>
      <div>
        <BasicExample/>
      </div>
      <div>
        <CarouselCustomerLogin/>
      </div>
      <div>
        <SignIn /> 
      </div>
      <div>
        <Lfooter />
      </div>
    </div>
  )
}

export default Scustomer
import React from 'react'
import BasicExample from './Components/Navbar'
import CarouselChefLogin from './CarouselChefLogin';
import SignIn from './Components/FormLogin';
import Lfooter from './Components/FooterCom';

function Schef() {
  return (
    <div>
      <div>
        <BasicExample/>
      </div>
      <div>
        <CarouselChefLogin/>
      </div>
      <div>
        <SignIn /> 
      </div>
      <div>
        <Lfooter />
      </div>
    </div>
  )
}

export default Schef
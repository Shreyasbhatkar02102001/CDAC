import React from 'react'
import BasicExample from './Components/Navbar'
import CustomCarouselAdminLogin from './Components/CarouselAdminLogin';
import SignIn from './Components/FormLogin';
import Lfooter from './Components/FooterCom';

function Sadmin() {   //  Login example
    const [count, setCount] = useState(0)
  
    return (
      <div>
        <div>
          <BasicExample />
        </div>
        <div>
          <CustomCarouselAdminLogin/>
        </div>
        <div>
          <SignIn/>
        </div>
        <div>
          <Lfooter />
        </div>
      </div>
    )
  }
  
  export default Sadmin
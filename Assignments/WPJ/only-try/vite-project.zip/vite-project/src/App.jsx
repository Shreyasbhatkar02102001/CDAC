import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react'
import './App.css'
import BasicExample from './Components/Navbar'
import CustomCarousel from './Components/CarouselAdminRegis'
import CustomCarouselAdminLogin from './Components/CarouselAdminLogin';
import NavAdminExample from './Components/NavbarAdmin';
import ResponsiveExample from './Components/FormRegister';
import SignIn from './Components/FormLogin';
import Lfooter from './Components/FooterCom';


// function App() {   // Resgister
//   const [count, setCount] = useState(0)

//   return (
//     <div>
//       <div>
//         <BasicExample />
//       </div>
//       <div>
//         <CustomCarousel />
//       </div>
//       <div>
//         <ResponsiveExample /> 
//       </div>
//       <div>
//         <Lfooter />
//       </div>
//     </div>
//   )
// }

// export default App

// function App() {   //  Login example
//   const [count, setCount] = useState(0)

//   return (
//     <div>
//       <div>
//         <BasicExample />
//       </div>
//       <div>
//         <CustomCarouselAdminLogin/>
//       </div>
//       <div>
//         <SignIn/>
//       </div>
//       <div>
//         <Lfooter />
//       </div>
//     </div>
//   )
// }

// export default App


function App() {  
  const [count, setCount] = useState(0)

  return (
    <div>
      <div>
        <BasicExample/>
      </div>
      <div>
        <CustomCarousel />
      </div>
      <div>
        <ResponsiveExample /> 
      </div>
      <div>
        <Lfooter />
      </div>
    </div>
  )
}

export default App

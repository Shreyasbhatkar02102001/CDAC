export const ROUTES = Object.freeze({
    HOME:"/",
    ADD_PRODUCT:"/add-product",
    PRODUCTS_LIST: "/products-list"
});
export const API_BASE_URL = 'http://127.0.0.1:9800';
export const PRODUCTS_API_URL = `${API_BASE_URL}/products`;
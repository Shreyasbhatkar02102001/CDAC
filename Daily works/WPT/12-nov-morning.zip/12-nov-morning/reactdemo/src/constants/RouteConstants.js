export const ROUTES = Object.freeze({
    HOME: '/',
    ABOUT: '/about',
    CONTACT: '/contact'
});
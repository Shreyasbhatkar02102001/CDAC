export const BASE_URL = "http://127.0.0.1:9800";
export const PRODUCTS_API_URL = `${BASE_URL}/products`;
export const ADMIN_API_URL = `${BASE_URL}/admin`;
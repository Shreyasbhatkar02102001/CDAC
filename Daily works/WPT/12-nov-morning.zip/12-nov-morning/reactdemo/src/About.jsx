export function About(){
    return (
        <div>
            <h1>Know about us</h1>
            <h3>Our Mission</h3>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dignissimos dicta accusantium veniam, neque beatae laudantium iure, illum nesciunt odio animi nihil, quae itaque enim voluptate magni ipsum nostrum minima maxime?</p>
            <h3>Our Vision</h3>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Temporibus natus qui non hic reiciendis corrupti eveniet dolorem, labore at nulla numquam ad impedit culpa sit consequuntur minus ducimus beatae deserunt?</p>
        </div>
    )
}
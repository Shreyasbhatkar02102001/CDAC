export function Contact(){
    return (
        <div>
            <h1>Contact Us</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fuga odit nisi autem aliquam exercitationem dolor est explicabo, earum quaerat dolorum quia sit. Deleniti officia molestiae quae dolor in nisi suscipit!</p>
            <p>Email: 123@example.com</p>
            <p>Phone: +1 123-456-7890</p>
            <p>Address: 123 Main St, City, State, Zip</p>
        </div>
    )
}
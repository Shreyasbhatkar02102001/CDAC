export function incrementScore(){
    return {
        type: "INCREMENT"
    }
}

export function decrementScore(){
    return {
        type: "DECREMENT"
    }
}
import express from 'express';
import mysql from 'mysql';
// import { connectDatabase, getConnectionObject } from './dbConfig.js';

const connectionConfig = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'mydb'
});


const APP = express();
APP.use(express.json());

const PORT = 5600;
const STUDENTS_LIST = [];

APP.get("/", (request, response) => {
    response.send("Welcome to app");
});

APP.post("/sum", (request, response) => {
    const a = request.body.n1;
    const b = request.body.n2;
    const c = a + b;
    response.send({ sum: c });
});

APP.post("/register-student", (request, response) => {
    try {
        const data = request.body;// {id:11,name:''}
        connectionConfig.query(`insert into student values(${data.id},'${data.name}',${data.marks},'${data.phone}')`,(error,result)=>{
            if(error){
                console.log(error);
                response.status(500).send({ message: "Something went wrong" }) 
            }
            else{
                console.log(result);
                response.status(201).send({ message: "Student registration successful" });
            }
        });
        
    } catch (error) {
        response.status(500).send({ message: "Something went wrong" })
    }
});

APP.get("/students", (request, response) => {
    try {
        response.status(200).send(STUDENTS_LIST);
    } catch (error) {
        response.status(500).send({ message: "Something went wrong" })
    }
});

APP.get("/students/:id", (request, response) => {
    try {
        const id = parseInt(request.params.id);
        const student = STUDENTS_LIST.find(s => s.id === id);
        if (student) {
            response.status(200).send(student);
        } else {
            response.status(404).send({ message: "Student not found" });
        }
    } catch (error) {
        response.status(500).send({ message: "Something went wrong" })
    }
});

APP.listen(PORT, () => {
    console.log(`Server is running at http://127.0.0.1:${PORT}`);
    // connectDatabase();
    // connect to database
    connectionConfig.connect(function (err) {
        if (err){
            console.log(err);
        }
        else{
            console.log('You are now connected with mysql database...')
        }
        
    });
});
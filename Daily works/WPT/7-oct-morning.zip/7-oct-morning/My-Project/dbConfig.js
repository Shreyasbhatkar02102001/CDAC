// import { createConnection } from "mysql";

// export function getConnectionObject(){
//     const connectionConfig = createConnection({
//         host: "localhost",
//         user: "root",
//         password: "root",
//         database: "mydb"
//     });
//     return connectionConfig;
// }
// export function connectDatabase(){
//     const connectionConfig = getConnectionObject();
//     connectionConfig.connect((error)=>{
//         if(error){
//             console.log(error);
//         }
//         else{
//             console.log("Connected to MySQL db");
//         }
//     })
// }

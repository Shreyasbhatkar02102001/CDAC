
namespace HR
{
    public interface IPresentable
    {
        void Present();
    }
}
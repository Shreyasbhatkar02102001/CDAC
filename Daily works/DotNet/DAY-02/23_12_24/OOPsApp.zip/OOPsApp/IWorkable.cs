
namespace HR{

    //Interface is nothing but a contract
    //Interface is a reference type
    //Interface can have only method declaration
    //Interface can have only method signature
    //Interface can have only method prototype
    //Interface can have only method abstract
    //Interface can have only method public

    public interface IWorkable{
        void Work();
    }
}
﻿namespace AcctMgmt;

public class Class1
{

}

﻿namespace OnlineShoppingPortal.Models
{
    public class Cart
    {
        public List<Item> Items { get; set; }
        public double Total { get; set; }
    }
}

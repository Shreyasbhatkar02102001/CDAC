﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace WebAppConnectionControllerApp.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IConfiguration _configuration;
        public ProductsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult Index()
        {

            string connectionString = _configuration.GetConnectionString("MyDatabase");
            ViewData["ConnectionString"] = connectionString;

            return View();
        }
    }
}

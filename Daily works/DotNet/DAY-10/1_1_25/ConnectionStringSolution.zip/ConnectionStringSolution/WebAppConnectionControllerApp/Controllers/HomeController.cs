using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebAppConnectionControllerApp.Models;

namespace WebAppConnectionControllerApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly string _connectionString;


        public HomeController(ILogger<HomeController> logger, string connectionString)
        {
            _logger = logger;
            _connectionString = connectionString;
        }

        public IActionResult Index()
        {
            // You can now use the _connectionString variable
            ViewData["ConnectionString"] = _connectionString;

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

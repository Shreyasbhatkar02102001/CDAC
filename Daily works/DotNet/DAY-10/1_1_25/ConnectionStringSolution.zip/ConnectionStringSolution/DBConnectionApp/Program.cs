﻿// Build the configuration to read from appsettings.json
using Microsoft.Extensions.Configuration;

// Set the base path to the directory of the executable

var configuration = new ConfigurationBuilder()
    .SetBasePath(AppDomain.CurrentDomain.BaseDirectory) 
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .Build();

// Get the connection string from the appsettings.json
string connectionString = configuration.GetConnectionString("MyDatabase");

// Output the connection string (or use it in your application logic)
Console.WriteLine($"Connection String: {connectionString}");

// Additional logic using the connection string
// Example: creating a connection to a database, etc.
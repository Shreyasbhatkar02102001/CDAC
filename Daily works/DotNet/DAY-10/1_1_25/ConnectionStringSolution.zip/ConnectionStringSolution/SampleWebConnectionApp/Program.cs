var builder = WebApplication.CreateBuilder(args);
var configuration = builder.Configuration;
string connectionString = configuration.GetConnectionString("MyDatabase");
Console.WriteLine($"Connection String: {connectionString}");

//IOC container Service Configuration
builder.Services.AddControllersWithViews();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

// Middlewre Configuration
app.UseRouting();
app.UseAuthorization();
app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();

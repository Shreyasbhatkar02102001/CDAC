﻿using WebLayeredApp.Entities;

namespace WebLayeredApp.Repositories
{
    public interface IProductRepository
    {

        List<Product> GetProducts();
    }
}

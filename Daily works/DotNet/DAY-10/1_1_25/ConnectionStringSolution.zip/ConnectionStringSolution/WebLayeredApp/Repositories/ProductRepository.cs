﻿using WebLayeredApp.Entities;

namespace WebLayeredApp.Repositories
{
    public class ProductRepository : IProductRepository
    {

        public string _conString;
        private readonly IConfiguration _configuration;

        public ProductRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _conString = this._configuration.GetConnectionString("MyDatabase");
        }

        public List<Product> GetProducts()
        {
            Console.WriteLine(" Repository GetProducts");
            Console.WriteLine(_conString);
            List<Product> products = new List<Product>();

            //database connectivity Code
            //using Connected or Disconnected Architecture to get data from database 
            // or using Entity Framework to get data from database


            return products;


        }
    }
}

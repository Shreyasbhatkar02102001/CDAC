﻿using WebLayeredApp.Entities;
using WebLayeredApp.Repositories;

namespace WebLayeredApp.Services
{
    public class ProductService : IProductService
    {

        private readonly IProductRepository _repo;

        public ProductService(IProductRepository repo)
        {
            _repo = repo;
        }
        public List<Product> GetProducts()
        {
            return _repo.GetProducts();

           
        }
    }
}

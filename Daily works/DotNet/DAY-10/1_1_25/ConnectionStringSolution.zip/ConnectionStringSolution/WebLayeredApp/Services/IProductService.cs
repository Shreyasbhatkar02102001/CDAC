﻿using WebLayeredApp.Entities;

namespace WebLayeredApp.Services
{
    public interface IProductService
    {

        List<Product> GetProducts();

    }
}

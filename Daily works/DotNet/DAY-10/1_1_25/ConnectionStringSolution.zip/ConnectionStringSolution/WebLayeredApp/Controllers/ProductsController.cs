﻿using Microsoft.AspNetCore.Mvc;
using WebLayeredApp.Entities;
using WebLayeredApp.Services;

namespace WebLayeredApp.Controllers
{
    public class ProductsController : Controller
    {

        private readonly IProductService _productService;


        public ProductsController(IProductService productService)
        {
            _productService = productService;

        }
        public IActionResult Index()
        {

            List<Product> products = _productService.GetProducts();

            return View();
        }
    }
}

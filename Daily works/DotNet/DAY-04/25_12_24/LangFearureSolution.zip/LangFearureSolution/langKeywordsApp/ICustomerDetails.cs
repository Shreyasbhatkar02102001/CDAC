namespace CRM{

    public interface ICustomerDetails{
         void ShowDetails();
    }
}
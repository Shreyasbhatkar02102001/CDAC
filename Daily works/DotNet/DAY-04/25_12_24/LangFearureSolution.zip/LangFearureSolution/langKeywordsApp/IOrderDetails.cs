namespace CRM{

    public interface IOrderDetails{
         void ShowDetails();
    }
}
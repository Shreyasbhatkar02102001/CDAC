﻿using OnlineShoppingPortal.Models;

namespace OnlineShoppingPortal.Repositories
{

    //Serialization JSON

    public class JsonDataRespository : IDataRepository
    {
        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public List<Product> GetAll()
        {
            throw new NotImplementedException();
        }

        public Product GetById(int id)
        {
            throw new NotImplementedException();
        }

        public void Insert(Product product)
        {
            throw new NotImplementedException();
        }

        public void Update(Product product)
        {
            throw new NotImplementedException();
        }
    }
}

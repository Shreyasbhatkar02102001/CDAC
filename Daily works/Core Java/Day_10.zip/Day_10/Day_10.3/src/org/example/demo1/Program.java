package org.example.demo1;

public class Program {
	public static void main(String[] args) {
		float radius = 10.5f;
		float area = (float) (Math.PI * Math.pow(radius,2));
		System.out.println("Area	:	"+area);	
	}
	
	public static void main1(String[] args) {
		float length = 10;
		float breadth = 20;
		float area = length * breadth;
		System.out.println("Area	:	"+area);
	}
}

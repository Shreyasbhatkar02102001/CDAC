#ifndef STUDENT_H_		//Header Guard / Include Guard
#define STUDENT_H_
class Student
{
public:
	int RollNo;
	char Name[30];
	void GetData();		//Member Function Declaration
	void ShowData();

};
#endif /* STUDENT_H_ */

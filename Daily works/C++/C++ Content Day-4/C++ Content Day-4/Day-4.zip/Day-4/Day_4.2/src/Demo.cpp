#include <cstdio>
#include "../MyHeaderFile/Student.h"
#include "../MyHeaderFile/Student.h"

int main()
{
	Student s1;	//Object of class Student
	s1.GetData();		//Message Passing
	s1.ShowData();
	return 0;
}

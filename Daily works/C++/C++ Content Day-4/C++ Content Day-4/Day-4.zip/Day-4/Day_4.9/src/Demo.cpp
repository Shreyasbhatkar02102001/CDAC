#include <iostream>
//using namespace std;

int main()
{
	using namespace std;
	cout<<"Hello World";
	return 0;
}


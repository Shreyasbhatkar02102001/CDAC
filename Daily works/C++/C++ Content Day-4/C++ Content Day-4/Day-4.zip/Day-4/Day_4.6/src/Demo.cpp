#include <cstdio>

/*
int Num1=100;
int Num1=300;		//NOT OK
void SHow()			//OK
{

}
void SHow()			//NOT OK
{

}
int main()
{


	return 0;
}

*/

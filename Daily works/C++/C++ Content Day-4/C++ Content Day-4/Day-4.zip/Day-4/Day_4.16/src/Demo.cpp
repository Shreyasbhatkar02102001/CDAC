#include <iostream>
#include <string.h>
using namespace std;


void Add(int num1)
{
	cout<<"Am Sum";
}
void Add(int num1, int num2)
{
	cout<<"Am Sum";
}
void Add(float num1, int num2)
{
	cout<<"Am Sum";
}
void Add(int num1, float num2)
{
	cout<<"Am Sum";
}

int main()
{

	return 0;
}


int Var1=900;		//Global Variable

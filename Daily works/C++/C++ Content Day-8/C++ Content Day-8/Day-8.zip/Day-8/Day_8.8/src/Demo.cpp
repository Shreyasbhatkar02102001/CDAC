#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;
class Test
{
public:
	int Num1;
	int Num2;
	Test()
	{
		this->Num1=0;
		this->Num2=0;
	}
	Test(int Num1, int Num2)
	{
		this->Num1=Num1;
		this->Num2=Num2;
	}
	Test(Test &other)		//Copy Constructor
	{
		this->Num1=other.Num1;
		this->Num2=other.Num2;
	}
	void PrintData()
	{
		cout<<"Num1:	"<<this->Num1<<endl;
		cout<<"Num2:	"<<this->Num2<<endl;
	}
};
int main()
{
	Test t1(10,20);		//Parameterized cons will be called;
	Test t2;			//Parameterless cons will be called;
	t2=t1;				//Copy cons of the class will be called, Shallow Copy

	t1.PrintData();
	t2.PrintData();

	Test t3=t2;			//Shallow Copy
	return 0;
}

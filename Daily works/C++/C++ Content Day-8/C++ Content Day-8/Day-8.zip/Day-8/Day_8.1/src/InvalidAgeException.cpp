#include <string>
#include <iostream>
#include "../MyHeaderFiles/InvalidAgeException.h"
using namespace std;
InvalidAgeException::InvalidAgeException(string Message, int lineNumber, string FunctionName, string FileName):
		Message(Message),lineNumber(lineNumber),FunctionName(FunctionName),FileName(FileName)
	{

	}

	string InvalidAgeException:: GetMessage()
	{
		return this->Message;
	}

	void InvalidAgeException::printStackTrace()
	{
		cout<<this->Message<<" in "<<this->FileName<<" in "<<this->FunctionName<<" at "<<this->lineNumber<<endl;
	}

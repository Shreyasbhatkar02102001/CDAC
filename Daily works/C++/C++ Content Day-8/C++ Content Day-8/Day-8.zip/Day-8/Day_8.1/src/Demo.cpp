#include <iostream>
#include <string>
#include "../MyHeaderFiles/InvalidAgeException.h"
using namespace std;
class Student
{
public:
	string Name;
	int Age;


	void SetAge(int Age)
	{
		if(Age<0)
		{
			throw InvalidAgeException("Invalid Age",__LINE__,__FUNCTION__,__FILE__);
		}
		this->Age=Age;
	}



};
void AddStudentAge(int Age)
{
	Student s;
	s.SetAge(Age);
}
int main()
{

	int Age=-20;
	try
	{
		AddStudentAge(Age);
	}
	catch(InvalidAgeException &ex)
	{
		cout<<"Exception Occured:	"<<ex.GetMessage();
		ex.printStackTrace();
	}

	return 0;
}

#include <string>
using namespace std;
#ifndef INVALIDAGEEXCEPTION_H_
#define INVALIDAGEEXCEPTION_H_
class InvalidAgeException
{
private:
	string Message;
	int lineNumber;
	string FunctionName;
	string FileName;
public:
	InvalidAgeException(string Message, int lineNumber, string FunctionName, string FileName);
	string GetMessage();
	void printStackTrace();

};
#endif /* INVALIDAGEEXCEPTION_H_ */

#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;
class Test2
{
public:
	void AmGoodFriend();
	void AmBadFriend();
	friend class Test;

};
class Test
{
private:
	int Num1;
	int Num2;
public:

	Test()
	{
		this->Num1=0;
		this->Num2=0;
	}
	Test(int Num1, int Num2)
	{
		this->Num1=Num1;
		this->Num2=Num2;
	}
	Test(Test &other)		//Copy Constructor
	{
		this->Num1=other.Num1;
		this->Num2=other.Num2;
	}
	void PrintData()
	{
		cout<<"Num1:	"<<this->Num1<<endl;
		cout<<"Num2:	"<<this->Num2<<endl;
	}
	//friend void Test2::AmGoodFriend();

	friend class Test2;

};
void Test2::AmGoodFriend()
{
	Test t1;
	t1.Num1=100;
	t1.Num2=200;
	t1.PrintData();
};
int main()
{

	return 0;
}

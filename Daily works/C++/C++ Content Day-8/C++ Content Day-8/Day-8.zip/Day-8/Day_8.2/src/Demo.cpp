#include <iostream>
#include <string>
using namespace std;

int main()
{
	int *ptr=new int(100);
			//::operator new(sizeof(int));

	//cout<<"Value"<<*ptr;	//Defreferncing is not possible with void pointer
	cout<<"Value: "<<*ptr;

	delete ptr;
	ptr=nullptr;
	return 0;
}



int main4()
{
	//int *ptr=new int;		//GV
	//int *ptr=new int();	//0

	int *ptr=new int(1234);			//1234
	cout<<"Value:   "<<*ptr<<endl;

	delete ptr;		//deallocate memory of single variable

	//ptr=NULL;
	ptr=nullptr;
	return 0;
}
int main3()
{
	int *ptr=new int();			//0
	cout<<"Value:   "<<*ptr<<endl;

	delete ptr;		//deallocate memory of single variable

	ptr=NULL;
}
int main2()
{
	//new, it is used to allocate the memory dynamically
	//Delete, it is used to deallocate the memory dynamically

	int *ptr=new int; //GV		//It will allocate 4 byte memory into Heap Section for the integer data type

	cout<<"Value:   "<<*ptr<<endl;

	delete ptr;		//deallocate memory of single variable

	ptr=NULL;

	return 0;
}
int main1()
{

	int Num=100;		//Static Memory Allocation,Deallocation

	return 0;
}

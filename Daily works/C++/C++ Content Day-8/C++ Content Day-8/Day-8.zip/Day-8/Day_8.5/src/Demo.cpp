#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;
class Test
{
public:
	int Num1;
	int Num2;
	Test()
	{
		cout<<"Am cons of test"<<endl;
	}
	~Test()
	{
		cout<<"Am decons of test"<<endl;
	}
};
int main()
{
	//Test t1;					//Static Memory allocation to the object of Test class
	Test *ptr=new Test();		//Dynamic Memory Allocation to the object of Test Class
	delete ptr;
	ptr=nullptr;

	//Test *pt=(Test*)malloc(sizeof(Test));	//In this case cons and decons of class test will never get invoked

	return 0;
}

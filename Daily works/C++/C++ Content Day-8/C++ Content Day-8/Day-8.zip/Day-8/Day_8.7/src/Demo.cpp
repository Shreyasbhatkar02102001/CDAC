#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;
template<class T>
class Array
{
private:
	int Size;
	T *ptr;
public:
	Array()
	{
		this->Size=0;
		this->ptr=nullptr;
	}
	Array(int Size)
	{
		this->Size=Size;
		this->ptr=new T[Size];
	}
	void SetArray()
	{
		for(int i=0;i<this->Size;i++)
		{
			cout<<"Enter Elemenmt:	";
			cin>>ptr[i];
		}
	}
	void PrintArray()
	{
		for(int i=0;i<this->Size;i++)
			{
				cout<<ptr[i]<<"\t";
			}
	}

	~Array()
		{
			if(ptr!=nullptr)
			{
				delete[] ptr;
			}
			ptr=nullptr;
		}
};



int main()
{

	Array<float> farr(3);
	farr.SetArray();
	farr.PrintArray();
	return 0;
}

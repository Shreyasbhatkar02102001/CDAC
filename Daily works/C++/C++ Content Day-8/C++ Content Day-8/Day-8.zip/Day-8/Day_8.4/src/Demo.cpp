#include <iostream>
#include <string>
using namespace std;

int main()
{
	char Name[100];
	cout<<"Enter Name:"<<endl;
	cin>>Name;
	cout<<"The Name is:	"<<Name<<endl;

	int *ptr=new (&Name[50])int(100);

	cout<<"The Value is:	"<<*ptr<<endl;

	return 0;
}

#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;

class Array
{
private:
	int Size;
	int *ptr;
public:
	Array()
	{
		this->Size=0;
		this->ptr=nullptr;
	}
	Array(int Size)
	{
		this->Size=Size;
		this->ptr=new int[Size];
	}
	Array(Array &other)
	{
		this->Size=other.Size;
		//this->ptr=other.ptr;		//Shallow Copy
		this->ptr=new int[Size];	//Deep Copy
	}
	void SetArray()
	{
		for(int i=0;i<this->Size;i++)
		{
			cout<<"Enter Elemenmt:	";
			cin>>ptr[i];
		}
	}
	void PrintArray()
	{
		for(int i=0;i<this->Size;i++)
			{
				cout<<ptr[i]<<"\t";
			}
	}
	~Array();

};
Array::~Array()
	{
		if(ptr!=nullptr)
		{
			delete[] ptr;
		}
		ptr=nullptr;
	}


int main()
{

	Array a1(5);
	Array a2=a1;
	return 0;
}

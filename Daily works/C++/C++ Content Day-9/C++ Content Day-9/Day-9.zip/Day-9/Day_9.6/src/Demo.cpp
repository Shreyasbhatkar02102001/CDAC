#include <iostream>
using namespace std;

class Test
{
private:
	int Num1;
	int Num2;
public:
	Test()
	{
		this->Num1=0;
		this->Num2=0;
	}
	Test(int Num1, int Num2)
	{
		this->Num1=Num1;
		this->Num2=Num2;
	}
	void PrintData()
	{
		cout<<"Num1:	"<<this->Num1<<endl;
		cout<<"Num2:	"<<this->Num2<<endl;
	}

	friend Test operator-(Test &obj1, Test &obj2);
};

Test operator-(Test &obj1, Test &obj2)
{
	Test temp;
	temp.Num1=obj1.Num1-obj2.Num1;
	temp.Num2=obj1.Num2-obj2.Num2;
	return temp;
}


int main()
{
	Test t1(10,20);
	Test t2(30,40);
	Test t3=t1-t2;		//operator-(t1,t2);	//operator-(t1,t2);
	t3.PrintData();
	return 0;
}

#include <iostream>
using namespace std;

class MathOp
{
public:
	static int CalculateSquare(int Var)
	{
		return Var*Var;
	}
};




int main()
{
	cout<<MathOp::CalculateSquare(30);
	return 0;
}

#include <iostream>
using namespace std;
int main1()
{
	//extern static  int Num4;
	//cout<<"Num4:"<<Num4;
	return 0;
}

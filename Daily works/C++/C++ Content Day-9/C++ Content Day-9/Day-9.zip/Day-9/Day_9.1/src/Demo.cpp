#include <iostream>
using namespace std;
class Test
{
public:
	int Num1;			//Data Member, it will get memory inside object
	int Num2;			//Data Member, it will get memory inside object
	static int Num3;	//Class Level variable, will not get memory inside the object
public:
	int getNum1()
	{
		return this->Num1;
	}
	int getNum2()
	{
		return this->Num2;
	}
	int getNum3()
	{
		return this->Num3;
	}

};
static int Num4=100;		//Num4 is global static variable

int Test::Num3=100;		//Global Definition of static variable Num3


int main()
{
	Test t1,t2,t3;		//Statically created objects, Stack Frame
	cout<<"Num3:"<<t1.getNum3();
	return 0;
}

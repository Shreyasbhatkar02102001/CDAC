#include <iostream>
using namespace std;

class		//Anon Class
{
public:
	void Metho1()
	{
		cout<<"Am Non-Static Method1 of Demo"<<endl;
	}
	static void Method2()
	{
		cout<<"Am Static Method2 of Demo"<<endl;
	}
}d,d1,d2;		//here d,d1,d2 are the objects of above anon class
int main()
{
	d.Metho1();
	d.Method2();		//Static Method call with the help of object
	return 0;
}

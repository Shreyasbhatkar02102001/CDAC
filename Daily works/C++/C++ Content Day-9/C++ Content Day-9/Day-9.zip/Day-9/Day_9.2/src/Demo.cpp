#include <iostream>
using namespace std;
class Test
{
public:
	int Num1;			//Data Member, it will get memory inside object
	int Num2;			//Data Member, it will get memory inside object
	static int Num3;	//Class Level variable, will not get memory inside the object
public:
	int getNum1()
	{
		return this->Num1;
	}
	int getNum2()
	{
		return this->Num2;
	}
	static int getNum3()
	{
		//return this->Num3;
		return Test::Num3;
	}
	static void setNum3(int Num3)
	{
		//this->Num3=Num3;
		Test::Num3=Num3;
	}

	/*Test *const this*/
	void PrintData()
	{
		cout<<"Num1:	"<<this->Num1<<endl;
		cout<<"Num2:	"<<this->Num2<<endl;
		//cout<<"Num3:	"<<this->Num3<<endl;		//OK,
		cout<<"Num3:	"<<Test::Num3<<endl;
	}

};

int Test::Num3=100;		//Global Definition of static variable Num3


int main()
{
	Test t1;
	t1.Num1=100;
	t1.Num2=200;
	t1.PrintData();		//t1.PrintData(&t1)
	cout<<"--------------------------"<<endl;
	//t1.setNum3(300);		//Test::setNum3(300);	//OK
	Test::setNum3(300);		//Recommended
	t1.PrintData();
	Test::Num3=400;
	return 0;
}

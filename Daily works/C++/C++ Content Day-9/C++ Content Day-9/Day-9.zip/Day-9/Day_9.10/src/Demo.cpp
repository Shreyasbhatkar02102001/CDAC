#include <iostream>
using namespace std;

class Test
{
private:
	int Num1;
	int Num2;
public:
	Test()
	{
		this->Num1=0;
		this->Num2=0;
	}
	Test(int Num1, int Num2)
	{
		this->Num1=Num1;
		this->Num2=Num2;
	}


	friend ostream& operator<<(ostream &cout, Test &t1);
	friend istream& operator>>(istream &cin, Test &ob);


};
ostream& operator<<(ostream &cout, Test &t1)
	{
		cout<<"Num1:	"<<t1.Num1<<endl;
		cout<<"Num2:	"<<t1.Num2<<endl;
		return cout;
	}
istream& operator>>(istream &cin, Test &ob)
{
	cout<<"Enter Num1:"<<endl;
	cin>>ob.Num1;
	cout<<"Enter Num2:"<<endl;
	cin>>ob.Num2;
	return cin;
}

int main()
{
	Test t1;
	cin>>t1;
	cout<<"------------------------------------"<<endl;

	cout<<t1;
	return 0;
}

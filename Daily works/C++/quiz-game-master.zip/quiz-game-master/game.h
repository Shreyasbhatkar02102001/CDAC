#pragma once
#include<string>
using namespace std;
int login();
int signup();
void rules();
int topic();
int cpp();
int sports();
int maths();
int science();
int correct(int);
int wrong(int);
void invalid();
void trueorfalse(string,string,string,string,string,char);
//ALL THE FUNCTION WHICH ARE DEFINED IN GAME.CPP IS DECLARED HERE
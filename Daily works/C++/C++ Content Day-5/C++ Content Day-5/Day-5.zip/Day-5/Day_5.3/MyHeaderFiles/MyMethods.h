#ifndef MYMETHODS_H_
#define MYMETHODS_H_
extern "C"
{
int Method1();
int Method2();
int Method3();
int Method4();
}
#endif /* MYMETHODS_H_ */

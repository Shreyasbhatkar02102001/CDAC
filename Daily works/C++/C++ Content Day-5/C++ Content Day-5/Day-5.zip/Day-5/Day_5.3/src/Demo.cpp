#include <iostream>
#include "../MyHeaderFiles/MyMethods.h"
using namespace std;

int main()
{
	cout<<"Value Returned By Method1:	"<<Method1()<<endl;
	cout<<"Value Returned By Method2:	"<<Method2()<<endl;
	cout<<"Value Returned By Method3:	"<<Method3()<<endl;
	cout<<"Value Returned By Method4:	"<<Method4()<<endl;

	return 0;
}

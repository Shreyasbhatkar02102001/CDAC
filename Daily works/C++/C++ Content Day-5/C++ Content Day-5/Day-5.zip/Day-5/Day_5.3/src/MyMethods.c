int Method1()
{
	return 100;
}
int Method2()
{
	return 200;
}
int Method3()
{
	return 300;
}
int Method4()
{
	return 400;
}
